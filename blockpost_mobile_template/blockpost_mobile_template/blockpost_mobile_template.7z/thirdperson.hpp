#pragma once

namespace thirdperson
{
	extern void run( );
}

