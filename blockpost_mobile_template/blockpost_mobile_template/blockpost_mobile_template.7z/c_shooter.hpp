#pragma once

#include "il2cpp.hpp"
#include "constants.hpp"
#include "vec3.hpp"

class c_weapon_object
{
public:
	float& recoil_pattern( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1CC );
	}	
	float& recoil_vertical( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1BC );
	}	
	float& recoil_horizontal( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1C0 );
	}	
	float& spread_pattern( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1D0 );
	}	
	float& spread( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1C4 );
	}	
	float& stability( )
	{
		return *reinterpret_cast< float* >( ( uintptr_t ) this + 0x1C8 );
	}
	int& slot( )
	{
		return *reinterpret_cast< int* >( ( uintptr_t ) this + 0x320 );
	}
};

class c_shooter
{
public:
	static c_shooter* cs( )
	{
		auto domain = il2cpp::domain_get( );
		if ( !domain )
			return { };
		auto assembly = il2cpp::domain_assembly_open( domain, "Assembly-CSharp" );
		if ( !assembly )
			return { };
		auto plh = il2cpp::class_from_name( assembly->image, "", "Shooter" );
		if ( !plh )
			return { };
		auto field = il2cpp::class_get_field_from_name( plh, constants::shooter::cs );
		if ( !field )
			return { };
		void* players = nullptr;
		il2cpp::field_static_get_value( field, &players );

		return reinterpret_cast< c_shooter* >( players );
	}

	vec3_t& hands_pos( )
	{
		return *reinterpret_cast< vec3_t* >( ( uintptr_t ) this + 0x1D0 );
	}

	c_weapon_object* curwpn( )
	{
		return *reinterpret_cast< c_weapon_object** >( ( uintptr_t ) this + 0x20 );
	}
};