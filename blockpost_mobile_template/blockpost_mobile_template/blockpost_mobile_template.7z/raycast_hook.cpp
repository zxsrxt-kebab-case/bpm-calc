#include "raycast_hook.hpp"

#include "mem.hpp"
#include "aim.hpp"
#include "vec3.hpp"
#include "il2cpp.hpp"

namespace raycast_hook
{
	bool( *o_raycast )( vec3_t origin, vec3_t direction, void* hitinfo, float maxdistance, int lm );
	bool h_raycast( vec3_t origin, vec3_t direction, void* hitinfo, float maxdistance, int lm )
	{
		if ( silent::shoot )
		{
			direction = silent::pos - origin;
			silent::shoot = false;
		}
		return o_raycast( origin, direction, hitinfo, maxdistance, lm );
	}
	void hook( )
	{
		//auto ptr = il2cpp_assembly::open( "UnityEngine.PhysicsModule" )->image( )->get_class( "UnityEngine", "Physics" )
		//	->get_method( "Raycast", { "origin", "direction", "hitInfo", "maxDistance", "layerMask" } )->get_method_pointer( ); // TODO: FIX

		MH_CreateHook( reinterpret_cast< LPVOID >( mem::game_assembly + 0x23517E0), reinterpret_cast< LPVOID >( h_raycast ), reinterpret_cast< LPVOID* >( &o_raycast ) );
		MH_EnableHook( reinterpret_cast< LPVOID >( mem::game_assembly + 0x23517E0) );


	}
}	