#pragma once
#include "minhook/mh.h"

namespace raycast_hook
{
	extern void hook( );
}

