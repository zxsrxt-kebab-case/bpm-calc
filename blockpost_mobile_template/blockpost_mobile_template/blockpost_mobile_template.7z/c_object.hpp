#pragma once

class c_object
{
public:

};