#include "fonts.hpp"

namespace fonts
{
	ImFont* tahoma_bold = nullptr;
	ImFont* pixel = nullptr;
}