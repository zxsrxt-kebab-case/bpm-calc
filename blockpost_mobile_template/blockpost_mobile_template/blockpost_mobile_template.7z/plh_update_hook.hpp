#pragma once

namespace plh_update_hook
{
	extern void hook( );
}