#pragma once
namespace info
{
	struct screen_t
	{
		float x, y;
	};
	extern screen_t screen;
	extern void init( );
}
