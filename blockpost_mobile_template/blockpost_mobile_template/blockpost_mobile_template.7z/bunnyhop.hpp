#pragma once

namespace bunnyhop
{
	extern void run( );
}
