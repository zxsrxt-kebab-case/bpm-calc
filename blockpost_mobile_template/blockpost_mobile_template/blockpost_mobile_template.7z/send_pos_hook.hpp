#pragma once

namespace send_pos_hook
{
	extern void hook();
}