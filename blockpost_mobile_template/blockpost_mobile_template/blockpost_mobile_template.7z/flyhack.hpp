#pragma once

namespace flyhack
{
	extern void run( );
}

