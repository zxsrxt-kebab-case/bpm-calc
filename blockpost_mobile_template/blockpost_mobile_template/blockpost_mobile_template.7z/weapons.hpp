#pragma once

#include "c_shooter.hpp"

namespace weapons
{
	extern c_weapon_object* my_weapon;

	namespace no_recoil
	{
		extern void run( );
	}

	extern void run( );
}