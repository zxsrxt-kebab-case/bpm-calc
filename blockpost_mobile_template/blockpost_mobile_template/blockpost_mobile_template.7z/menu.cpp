#include "menu.hpp"
#include "vars.hpp"
#include "esp.hpp"
#include "aim.hpp"
#include "mem.hpp"
#include "info.hpp"
#include "thirdperson.hpp"
#include "il2cpp.hpp"

#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

#include "c_camera.hpp"

#include <Windows.h>

#include <mutex>
#include <thread>

#include "c_material.hpp"

il2cpp_method* mthd228 = nullptr;

namespace menu
{
	bool menu_opened = false;
	
	void handle_open( )
	{
		if ( ImGui::IsKeyPressed( ImGuiKey_Insert ) )
			menu_opened = !menu_opened;
	}

	
	void run( )
	{

		esp::run( );
		silent::run( );

		if(variables::silent || variables::psilent) ImGui::GetBackgroundDrawList( )->AddCircle( { info::screen.x / 2, info::screen.y / 2 }, static_cast<float>(variables::aim_fov), ImColor( 255, 255, 255 ), 999 );
		
		handle_open( );

		if ( !menu_opened )return;

		ImGui::SetNextWindowSize( { 300, 400 }, ImGuiCond_Once );

		ImGui::Begin( "blockpost mobile template", nullptr );
		if ( ImGui::BeginTabBar( "cheat" ) )
		{
			if ( ImGui::BeginTabItem( "visual" ) )
			{
				if ( ImGui::BeginTabBar( "visual settings" ) )
				{
					if ( ImGui::BeginTabItem( "esp" ) )
					{
						ImGui::Checkbox( "esp", &variables::esp );
						ImGui::Checkbox( "team check", &variables::teamcheck );
						ImGui::EndTabItem( );
					}
					if ( ImGui::BeginTabItem( "chams" ) )
					{
						ImGui::Checkbox( "enemy chams", &variables::chams::enemy::enable );
						ImGui::Checkbox( "local chams", &variables::chams::local::enable );
						ImGui::EndTabItem( );
					}				
					if ( ImGui::BeginTabItem( "world" ) )
					{
						ImGui::Checkbox( "thirdperson", &variables::thirdperson );
						ImGui::SliderFloat( "distance", &variables::third_distance, 0, 10 );
						ImGui::EndTabItem( );
					}
					ImGui::EndTabBar( );
				}
				ImGui::EndTabItem( );
			}
			if ( ImGui::BeginTabItem( "aim" ) )
			{
				ImGui::Checkbox( "silent aimbot", &variables::silent );
				ImGui::Checkbox( "perfect silent", &variables::psilent );
				ImGui::Checkbox( "autofire", &variables::autofire );
				ImGui::Checkbox( "autostop", &variables::autostop );
				ImGui::Checkbox( "autoscope", &variables::autoscope );
				ImGui::SliderInt( "fov", &variables::aim_fov, 0, 360, "%dut" );
				ImGui::EndTabItem( );
			}
			if ( ImGui::BeginTabItem( "movement" ) )
			{
				ImGui::Checkbox( "fly", &variables::flyhack );
				ImGui::Checkbox( "bhop", &variables::bunnyhop );
				ImGui::Checkbox( "autostrafe", &variables::autostrafe );
				ImGui::EndTabItem( );
			}
			if ( ImGui::BeginTabItem( "weapon" ) )
			{
				ImGui::Checkbox( "no recoil", &variables::weapons::no_recoil );
				ImGui::Checkbox( "no spread", &variables::weapons::no_spread );
				ImGui::EndTabItem( );
			}
			if ( ImGui::BeginTabItem( "antiaims" ) )
			{
				namespace var = variables::antiaims;
				namespace varv = variables::antiaims::visual;
				ImGui::Checkbox( "enabler", &var::enable );
				ImGui::Combo( "type", &var::type, "visual\0real\0" );

				if ( var::type == 0 )
				{
					if ( ImGui::CollapsingHeader( "selectors" ) )
					{
						ImGui::Combo( "yaw type", ( int* ) &varv::yaw_type, "static\0jitter\0spin" );
						if ( varv::yaw_type == varv::yaw_type_en::yaw_static )
						{
							ImGui::SliderInt( "yaw", &varv::static_yaw, -180, 180 );
						}
						if ( varv::yaw_type == varv::yaw_type_en::yaw_jitter )
						{
							ImGui::SliderInt( "yaw", &varv::jitter_yaw, -90, 90 );
						}
						ImGui::Combo( "pitch type", ( int* ) &varv::pitch_type, "static\0jitter" );
						if ( varv::pitch_type == varv::pitch_type_en::pitch_static )
						{
							ImGui::SliderInt( "pitch", &varv::static_pitch, -90, 90 );
						}
						if ( varv::pitch_type == varv::pitch_type_en::pitch_jitter )
						{
							ImGui::SliderInt( "pitch", &varv::jitter_pitch, -90, 90 );
						}
					}
				}
				ImGui::Checkbox( "fakeduck", &var::fakeduck );
				ImGui::EndTabItem( );
			}
			ImGui::EndTabBar( );
		}

		ImGui::End( );
	}
}