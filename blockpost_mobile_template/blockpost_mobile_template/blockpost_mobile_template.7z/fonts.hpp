#pragma once
#include "imgui/imgui.h"
namespace fonts
{
	extern ImFont* tahoma_bold;
	extern ImFont* pixel;
}

