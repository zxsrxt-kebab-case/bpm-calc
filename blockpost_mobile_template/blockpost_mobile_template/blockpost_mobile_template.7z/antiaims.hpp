#pragma once

namespace antiaims
{
	namespace visual
	{

		extern float in_rx, in_ry;
		extern float rx, ry;
		extern void run();
	}
}