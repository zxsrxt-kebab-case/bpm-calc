#pragma once

#include <Windows.h>

namespace mem
{
	extern DWORD64 game_assembly;
	extern void init( );
}

