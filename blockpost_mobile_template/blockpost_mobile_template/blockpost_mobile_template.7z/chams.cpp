#include "chams.hpp"

void chams::run( )
{
	enemy::run( );
	local::run( );
}