#pragma once
#include "vec3.hpp"

namespace aim
{
	extern void run( );
}
namespace silent
{
	extern float attached_rx, attached_ry;
	extern void run( );
	extern bool shoot;
	extern vec3_t pos;
}