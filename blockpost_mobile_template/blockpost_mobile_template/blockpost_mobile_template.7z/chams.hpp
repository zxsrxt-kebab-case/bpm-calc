#pragma once

namespace chams
{
	namespace local
	{
		extern void run( );
	}
	namespace enemy
	{
		extern void run( );
	}
	extern void run( );
}