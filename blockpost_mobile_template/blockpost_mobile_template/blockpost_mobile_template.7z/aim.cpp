#include "aim.hpp"

namespace aim
{
	void run( )
	{
		//later
	}
}