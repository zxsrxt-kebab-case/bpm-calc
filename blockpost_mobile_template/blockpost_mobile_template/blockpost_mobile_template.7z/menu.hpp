#pragma once
namespace menu
{
	extern void run( );
}

